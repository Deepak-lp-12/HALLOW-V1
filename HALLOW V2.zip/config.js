const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["2347085619245@s.whatsapp.net"]
global.nomerOwner = "2347085619245"
global.nomorOwner = ['2347085619245']
global.namaDeveloper = "Pain" //jangn diubh bng
global.namaOwner = "*LEVI"
global.namaBot = " 𝙃𝘼𝙇𝙇𝙊𝙒 𝙑2"
global.versionBot = "𝟏𝟓.𝟎.𝟐"
global.packname = "Levi"
global.author = "LEVI"
global.thumb = fs.readFileSync("./Andrazyy Forger.jpg")
global.ThM = 'https://files.catbox.moe/w2as7v.webp'
let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})